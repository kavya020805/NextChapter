import React from 'react';

const DownloadLocalData = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Download Books Data</h1>
      <p>This component will download books data for local testing.</p>
    </div>
  );
};

export default DownloadLocalData;

